print('script')
